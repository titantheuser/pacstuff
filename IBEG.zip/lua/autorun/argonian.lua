
	list.Set( "PlayerOptionsModel", "Argonian", "models/argonian.mdl" )
	player_manager.AddValidModel( "Argonian", "models/argonian.mdl" )
	player_manager.AddValidHands( "Argonian", "models/argonianarms.mdl", 0, "00000000" )
	

	AddCSLuaFile( "argonian.lua" )

